module.exports=[76797,a=>{"use strict";var b=a.i(22918);a.s([],3966),a.i(3966),a.s(["40eb9434d61a7a3ddfe6aeb956cca988dded1ede63",()=>b.getStudentExitReport],76797)}];

//# sourceMappingURL=_next-internal_server_app_admin_reports_students_page_actions_c597f172.js.map