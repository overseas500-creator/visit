module.exports=[36962,a=>{"use strict";var b=a.i(22918);a.s([],97140),a.i(97140),a.s(["40200a664f5c2ee750d26f2364606e8ec62da4ae14",()=>b.confirmExitPermit,"40c7859d8c2f40f25b029e45ac430d57f8d92450b7",()=>b.getExitPermits],36962)}];

//# sourceMappingURL=_next-internal_server_app_guard_page_actions_15bd087b.js.map