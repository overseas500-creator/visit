globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/1d2cc420cf9a026c.js",
    "static/chunks/ac9a338116aab6b6.js",
    "static/chunks/30ea11065999f7ac.js",
    "static/chunks/5434d5ef4f2a5edf.js",
    "static/chunks/236f7e5abd6f09ff.js",
    "static/chunks/turbopack-d7df57af61fe2bf5.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];